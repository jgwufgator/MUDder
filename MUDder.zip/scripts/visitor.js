function visitor(rooms, startingRoom) {

}