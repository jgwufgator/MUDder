function CommandHandler(){

	var self = this;	

	this.handleInput = function(commandData)
	{
		
	};
}